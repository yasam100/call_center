﻿namespace PresentationLayer.Models
{
    public class ServiceIssue
    {
        public int Id { get; set; }

    }
}